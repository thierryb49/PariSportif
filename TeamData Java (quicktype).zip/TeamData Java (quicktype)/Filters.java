package org.tune.parisportif.footballdata;

import java.util.*;
import com.fasterxml.jackson.annotation.*;

@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.NONE)
public class Filters {
}
